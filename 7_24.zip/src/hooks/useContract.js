import Web3 from "web3";
import marketAbi from "../contracts/Marketplace.json";

export const web3 = new Web3(window.ethereum);

export const ContractAddress = "0xBBC9f06400d8167Cc65323Bb7Fe88b2bF5FcC5a3";

const ContractInstance = new web3.eth.Contract(marketAbi, ContractAddress);

export default ContractInstance;