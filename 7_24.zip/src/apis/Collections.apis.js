import axios from "axios";

const createCollection = async (data) => {
  try {
    const response = await axios.post(
      "http://localhost:90/addCollection",
      data,
      {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      }
    );
    return response;
  } catch (error) {
    console.log(error);
  }
};

const getCollections = async (EthUser) => {
  try {
    const response = await axios.post("http://localhost:90/getCollection", {
      EthUser,
    });
    return response.data;
  } catch (error) {}
};

const updateCollectionById = async (id) => {
  try {
    const response = await axios.post("http://localhost:90/updateCollection", {
      id,
    });
    return response.data;
  } catch (error) {
    console.log(error);
  }
};

export { createCollection, getCollections, updateCollectionById };
