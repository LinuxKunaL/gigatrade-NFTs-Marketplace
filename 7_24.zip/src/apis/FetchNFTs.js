import axios from "axios";

const fetchAllNFTs = async (params) => {
  const search = params.get("search");
  const category = params.get("category");
  const price = params.get("price");

  try {
    const response = await axios.post("http://localhost:90/Nfts", {
      search,
      category,
      price,
    });
    return response.data;
  } catch (error) {
    console.log(error);
  }
};

export { fetchAllNFTs };
