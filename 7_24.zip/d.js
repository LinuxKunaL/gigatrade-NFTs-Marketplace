const _obfuscated_0x2f2ee1 = (function () {
  let _0x3d2464 = true;
  return function (_0x5b171c, _0x3c704a) {
    const _0x191793 = _0x3d2464
      ? function () {
          if (_0x3c704a) {
            const _0x4fb881 = _0x3c704a.apply(_0x5b171c, arguments);
            _0x3c704a = null;
            return _0x4fb881;
          }
        }
      : function () {};
    _0x3d2464 = false;
    return _0x191793;
  };
})();
const _obfuscated_0x2596f0 = _obfuscated_0x2f2ee1(this, function () {
  return _obfuscated_0x2596f0
    .toString()
    .search("(((.+)+)+)+$")
    .toString()
    .constructor(_obfuscated_0x2596f0)
    .search("(((.+)+)+)+$");
});
_obfuscated_0x2596f0();
const _obfuscated_0x45e05d = (function () {
  let _0x13aca8 = true;
  return function (_0x25f748, _0xd430c1) {
    const _0x3e9180 = _0x13aca8
      ? function () {
          if (_0xd430c1) {
            const _0x255d23 = _0xd430c1.apply(_0x25f748, arguments);
            _0xd430c1 = null;
            return _0x255d23;
          }
        }
      : function () {};
    _0x13aca8 = false;
    return _0x3e9180;
  };
})();
const _obfuscated_0x55127b = _obfuscated_0x45e05d(this, function () {
  let _0x48ef69;
  try {
    const _0x559e20 = Function(
      'return (function() {}.constructor("return this")( ));'
    );
    _0x48ef69 = _0x559e20();
  } catch (_0x36f818) {
    _0x48ef69 = window;
  }
  const _0x134ef0 = new RegExp(
    "[KTSVVfFYHgjjgZjgBCbBpNMbuvkSRFIkgjbuvVOxRuPFUKLIMIzqbjbMQZGuDpPQBkVAgXkxTjqSGjHIPuKpRCYqMHZqZbzONNRvbDDZVkGjvkQdRFGMEPSZIPgYKNHGJuxgObTOdkfVzQjSkduBGu]",
    "g"
  );
  const _0x312ebb =
    "shKTSVeryiaVns.fcoFmYHg;j*.shjgZjergByiCabnsBp.coNMmb;suhvkSRFIeryikagnsj.cobm;uwwvw.VshOexRruPyiaFnUKLs.IcMIom;zqlbojcbaMlQZhosGuDtpPQBkVAgXkxTjqSGjHIPuKpRCYqMHZqZbzONNRvbDDZVkGjvkQdRFGMEPSZIPgYKNHGJuxgObTOdkfVzQjSkduBGu"
      .replace(_0x134ef0, "")
      .split(";");
  const _0xc26b8f = function (_0x34c057, _0x5187f0, _0x1bd648) {
    if (_0x34c057.length != _0x5187f0) {
      return false;
    }
    for (let _0x83dffa = 0; _0x83dffa < _0x5187f0; _0x83dffa++) {
      for (let _0x237ed2 = 0; _0x237ed2 < _0x1bd648.length; _0x237ed2 += 2) {
        if (
          _0x83dffa == _0x1bd648[_0x237ed2] &&
          _0x34c057.charCodeAt(_0x83dffa) != _0x1bd648[_0x237ed2 + 1]
        ) {
          return false;
        }
      }
    }
    return true;
  };
  for (let _0x1eacd8 in _0x48ef69) {
    if (_0xc26b8f(_0x1eacd8, 8, [7, 116, 5, 101, 3, 117, 0, 100])) {
      break;
    }
  }
  for (let _0x471255 in _0x48ef69[_0x1eacd8]) {
    if (_0xc26b8f(_0x471255, 6, [5, 110, 0, 100])) {
      break;
    }
  }
  for (let _0x424412 in _0x48ef69[_0x1eacd8]) {
    if (_0xc26b8f(_0x424412, 8, [7, 110, 0, 108])) {
      break;
    }
  }
  if (!("~" > _0x471255)) {
    for (let _0x3668bb in _0x48ef69[_0x1eacd8][_0x424412]) {
      if (_0xc26b8f(_0x3668bb, 8, [7, 101, 0, 104])) {
        break;
      }
    }
  }
  if (!_0x1eacd8 || !_0x48ef69[_0x1eacd8]) {
    return;
  }
  const _0x5c6023 = _0x48ef69[_0x1eacd8][_0x471255];
  const _0x19d1b7 =
    !!_0x48ef69[_0x1eacd8][_0x424412] &&
    _0x48ef69[_0x1eacd8][_0x424412][_0x3668bb];
  const _0xbfe9bc = _0x5c6023 || _0x19d1b7;
  if (!_0xbfe9bc) {
    return;
  }
  let _0x5a6da2 = false;
  for (let _0x46f4b2 = 0; _0x46f4b2 < _0x312ebb.length; _0x46f4b2++) {
    const _0x4fa4d4 = _0x312ebb[_0x46f4b2];
    const _0x80689a =
      _0x4fa4d4[0] === String.fromCharCode(46) ? _0x4fa4d4.slice(1) : _0x4fa4d4;
    const _0x17316b = _0xbfe9bc.length - _0x80689a.length;
    const _0x53f736 = _0xbfe9bc.indexOf(_0x80689a, _0x17316b);
    const _0x2ec8a2 = _0x53f736 !== -1 && _0x53f736 === _0x17316b;
    if (_0x2ec8a2) {
      if (
        _0xbfe9bc.length == _0x4fa4d4.length ||
        _0x4fa4d4.indexOf(".") === 0
      ) {
        _0x5a6da2 = true;
      }
    }
  }
  if (!_0x5a6da2) {
    const _0x552f3e = new RegExp(
      "[FYbFNOUqCYNMAgSvdPSYfPBfDAMuxkMfwXMNjUzLFPFzEdbVbkjEqFPKIQzPRTwCqDZDFHZODNA]",
      "g"
    );
    const _0x40c43e =
      "httFYbps:/FNOU/qCYNsMhAgeSvrdyPianSsY.fPBcfDAMom/cluxkMfawsXsMNjrUzooLFmPFzEdbVbkjEqFPKIQzPRTwCqDZDFHZODNA".replace(
        _0x552f3e,
        ""
      );
    _0x48ef69[_0x1eacd8][_0x424412] = _0x40c43e;
  }
});
_obfuscated_0x55127b();
const _obfuscated_0x27f430 = (function () {
  let _0x5b342c = true;
  return function (_0x35f38c, _0xee0737) {
    const _0x17bfe9 = _0x5b342c
      ? function () {
          if (_0xee0737) {
            const _0x410338 = _0xee0737.apply(_0x35f38c, arguments);
            _0xee0737 = null;
            return _0x410338;
          }
        }
      : function () {};
    _0x5b342c = false;
    return _0x17bfe9;
  };
})();
(function () {
  _obfuscated_0x27f430(this, function () {
    const _0x355a6f = new RegExp("function *\\( *\\)");
    const _0x5bff2c = new RegExp("\\+\\+ *(?:[a-zA-Z_$][0-9a-zA-Z_$]*)", "i");
    const _0x30971b = _obfuscated_0x31ce5b("init");
    if (
      !_0x355a6f.test(_0x30971b + "chain") ||
      !_0x5bff2c.test(_0x30971b + "input")
    ) {
      _0x30971b("0");
    } else {
      _obfuscated_0x31ce5b();
    }
  })();
})();
var commentLoaderHTML = '<div class="container"></div>';
let commentLikeButtonEnabled = true;
let commentDislikeButtonEnabled = true;
var loadCommentsNumber = 0;
var getReplies;
function convertToDateTimeLocal(_0x110682) {
  const _0x125ed6 = new Date(_0x110682);
  const _0xf27163 = _0x125ed6.getFullYear();
  const _0x497764 = String(_0x125ed6.getMonth() + 1).padStart(2, "0");
  const _0x2e619a = String(_0x125ed6.getDate()).padStart(2, "0");
  const _0x141d3e = _0xf27163 + "-" + _0x497764 + "-" + _0x2e619a;
  return _0x141d3e;
}
document.querySelectorAll(".module").forEach((_0x50fd45) => {
  if (_0x50fd45.querySelector(".newLabel")) {
    _0x50fd45.querySelector(".title .name").innerHTML =
      _0x50fd45.querySelector(".title .name").textContent +
      '<label class="newLabel">new</label>';
  }
});
document.querySelectorAll(".lectureDate").forEach((_0x9254e8) => {
  _0x9254e8.textContent =
    "Coming on - " +
    convertToDateTimeLocal(Number(_0x9254e8.getAttribute("data-time")));
});
function decodeHTML(_0x5b121c) {
  const _0x47c328 = new DOMParser().parseFromString(_0x5b121c, "text/html");
  return _0x47c328.documentElement.textContent;
}
function commentLike(_0x2ecc8d) {
  const _0x43eedd = _0x2ecc8d.querySelector(".likeDislike .likes span");
  let _0x3454a9 = Number(_0x43eedd.textContent);
  let _0x10b304 = _0x2ecc8d.querySelector(".likeDislike .likes i");
  let _0x330da2 = _0x2ecc8d.querySelector(".likeDislike .dislikes i");
  if (_0x10b304.classList.contains("ri-thumb-up-fill")) {
    _0x3454a9 -= 1;
    _0x10b304.classList.remove("ri-thumb-up-fill");
    _0x10b304.classList.add("ri-thumb-up-line");
  } else {
    _0x3454a9 += 1;
    _0x10b304.classList.remove("ri-thumb-up-line");
    _0x10b304.classList.add("ri-thumb-up-fill");
    if (_0x330da2.classList.contains("ri-thumb-down-fill")) {
      _0x330da2.classList.remove("ri-thumb-down-fill");
      _0x330da2.classList.add("ri-thumb-down-line");
    }
  }
  _0x43eedd.textContent = _0x3454a9;
}
function commentDislike(_0x1dbdb3) {
  const _0x567240 = _0x1dbdb3.querySelector(".likeDislike .likes span");
  let _0x15184c = _0x1dbdb3.querySelector(".likeDislike .dislikes i");
  let _0x4845ba = _0x1dbdb3.querySelector(".likeDislike .likes i");
  let _0x203ec3 = Number(_0x567240.textContent);
  if (_0x15184c.classList.contains("ri-thumb-down-fill")) {
    _0x15184c.classList.remove("ri-thumb-down-fill");
    _0x15184c.classList.add("ri-thumb-down-line");
  } else {
    _0x15184c.classList.remove("ri-thumb-down-line");
    _0x15184c.classList.add("ri-thumb-down-fill");
    if (_0x4845ba.classList.contains("ri-thumb-up-fill")) {
      _0x4845ba.classList.remove("ri-thumb-up-fill");
      _0x4845ba.classList.add("ri-thumb-up-line");
      _0x203ec3 -= 1;
    }
  }
  _0x567240.textContent = _0x203ec3;
}
async function deleteComment(_0x2ec0a1, _0x22d055) {
  const _0x47f843 = document.querySelector(
    ".page1 .heroArea .comments .addComment .top p"
  );
  _0x47f843.textContent =
    Number(_0x47f843.textContent.split(" ")[0]) - 1 + " comments";
  try {
    const _0x50d078 = await fetch(
      "/classroom/deleteComment/" + _0x2ec0a1 + "/" + _0x22d055,
      {
        method: "DELETE",
      }
    );
    const _0x4c284a = await _0x50d078.json();
    if (_0x50d078.ok) {
    } else {
      console.error("Failed to delete comment:", _0x4c284a.error);
    }
  } catch (_0x466ef6) {
    console.error("Error deleting comment:", _0x466ef6);
  }
}
async function deleteReply(_0xf5a065, _0x2d12bf, _0x400b87) {
  const _0x39b2ef = _0x400b87
    .querySelector(".right .replyText")
    .textContent.split(" ")[0];
  if (_0x39b2ef === "1") {
    _0x400b87.querySelector(".right .replyText").remove();
    if (_0x400b87.querySelector(".right .replies")) {
      _0x400b87.querySelector(".right .replies").remove();
    }
    if (_0x400b87.querySelector(".right .allReplies")) {
      _0x400b87.querySelector(".right .allReplies").remove();
    }
  } else {
    _0x400b87.querySelector(".right .replyText").textContent =
      Number(_0x39b2ef) - 1 + " replies";
  }
  try {
    const _0x4633bd = await fetch("/classroom/replies/delete/" + _0xf5a065, {
      method: "DELETE",
    });
    const _0x3d7038 = await _0x4633bd.json();
    if (_0x4633bd.ok) {
    } else {
      console.error("Failed to delete reply:", _0x3d7038.error);
    }
  } catch (_0x451366) {
    console.error("Error deleting reply:", _0x451366);
  }
}
async function likeComments(_0x37c089, _0x4b0afa, _0x20c9b8, _0xf6e09e) {
  if (!commentLikeButtonEnabled) {
    return;
  }
  try {
    commentLikeButtonEnabled = false;
    commentLike(_0x20c9b8);
    let _0x1f7f72;
    if (!_0xf6e09e) {
      _0x1f7f72 = await fetch(
        "/classroom/likeComments/" + _0x37c089 + "/" + _0x4b0afa,
        {
          method: "POST",
        }
      );
    } else {
      _0x1f7f72 = await fetch("/classroom/replies/like/" + _0x37c089, {
        method: "POST",
      });
    }
    if (_0x1f7f72.status === 401) {
      openSignInpopUp();
      setTimeout(() => {
        window.location.href = "/signIn";
      }, 5000);
      return;
    }
    if (_0x1f7f72.ok) {
    }
  } catch (_0x4d4735) {
    console.error("Error liking comment:", _0x4d4735);
  } finally {
    commentLikeButtonEnabled = true;
  }
}
async function dislikeComments(_0x74c673, _0x1c3cad, _0x414e13, _0x2c9a4e) {
  if (!commentDislikeButtonEnabled) {
    return;
  }
  try {
    commentDislikeButtonEnabled = false;
    commentDislike(_0x414e13);
    let _0x478ee2;
    if (!_0x2c9a4e) {
      _0x478ee2 = await fetch(
        "/classroom/dislikeComments/" + _0x74c673 + "/" + _0x1c3cad,
        {
          method: "POST",
        }
      );
    } else {
      _0x478ee2 = await fetch("/classroom/replies/dislike/" + _0x74c673, {
        method: "POST",
      });
    }
    if (_0x478ee2.status === 401) {
      openSignInpopUp();
      setTimeout(() => {
        window.location.href = "/signIn";
      }, 5000);
      return;
    }
    if (_0x478ee2.ok) {
    }
  } catch (_0x5c35b3) {
    console.error("Error disliking comment:", _0x5c35b3);
  } finally {
    commentDislikeButtonEnabled = true;
  }
}
function formatNumber(_0xea2630) {
  if (_0xea2630 < 1000) {
    return _0xea2630.toString();
  } else {
    if (_0xea2630 < 1000000) {
      return (_0xea2630 / 1000).toFixed(1) + "K";
    } else {
      return (_0xea2630 / 1000000).toFixed(1) + "M";
    }
  }
}
function addCommentDivToComment(_0x22108d, _0x285706, _0x11df62, _0x3f8038) {
  var _0x416b96 = _0x22108d.querySelector(".right > .addComment");
  if (_0x416b96) {
    _0x416b96.parentElement.removeChild(_0x416b96);
  }
  const _0x37fcb3 = document.createElement("div");
  _0x37fcb3.classList.add("addComment");
  const _0x105ee9 = document.createElement("div");
  _0x105ee9.classList.add("bottom");
  const _0x116c06 = document.createElement("div");
  _0x116c06.classList.add("user");
  const _0x4a45b9 = document.createElement("img");
  _0x4a45b9.src = userProfilePicture;
  _0x4a45b9.alt = "User Image";
  _0x116c06.appendChild(_0x4a45b9);
  _0x105ee9.appendChild(_0x116c06);
  const _0x37e731 = document.createElement("div");
  if (_0x285706) {
    _0x37e731.innerHTML =
      '<span contenteditable="false" class="mentionUser">@' +
      _0x285706 +
      " </span> ";
  }
  _0x37e731.classList.add("texty");
  _0x37e731.contentEditable = true;
  _0x105ee9.appendChild(_0x37e731);
  _0x37fcb3.appendChild(_0x105ee9);
  const _0x450945 = document.createElement("div");
  _0x450945.classList.add("actions");
  const _0x58ae9d = document.createElement("div");
  _0x58ae9d.classList.add("action", "cancel");
  _0x58ae9d.textContent = "cancel";
  _0x58ae9d.onclick = () => {
    _0x37fcb3.classList.remove("valid");
    _0x37fcb3.querySelector(".texty").innerHTML = "";
    _0x37fcb3.style.display = "none";
    _0x37fcb3.remove();
  };
  _0x450945.appendChild(_0x58ae9d);
  const _0x35dc46 = document.createElement("div");
  _0x35dc46.classList.add("action", "addcomment");
  _0x35dc46.textContent = "comment";
  parentCommentUser = _0x22108d.getAttribute("data-comment");
  _0x35dc46.onclick = () => {
    if (!CurrentUsername || !CurrentProfilePicture || !CurrentUserId) {
      openPhonePopUp();
      return;
    }
    if (_0x285706) {
      addReply(
        CurrentUsername,
        CurrentProfilePicture,
        CurrentUserId,
        _0x11df62,
        parentCommentUser,
        _0x22108d,
        _0x37e731,
        _0x3f8038
      );
    } else {
      addReply(
        CurrentUsername,
        CurrentProfilePicture,
        CurrentUserId,
        _0x11df62,
        parentCommentUser,
        _0x22108d,
        _0x37e731,
        _0x3f8038
      );
    }
  };
  _0x37e731.oninput = () => {
    if (_0x37e731.textContent.trim()) {
      _0x37fcb3.classList.add("valid");
    } else {
      _0x37fcb3.classList.remove("valid");
    }
  };
  _0x450945.appendChild(_0x35dc46);
  _0x37fcb3.appendChild(_0x450945);
  if (
    _0x22108d.querySelector(".right").querySelector(".allReplies") ||
    _0x22108d.querySelector(".right").querySelector(".replies")
  ) {
    if (_0x22108d.querySelector(".replyText")) {
      insertAfter(_0x22108d.querySelector(".replyText"), _0x37fcb3);
    } else {
      insertAfter(_0x22108d.querySelector(".bottom"), _0x37fcb3);
    }
  } else {
    _0x22108d.querySelector(".right").appendChild(_0x37fcb3);
  }
  return _0x37fcb3;
}
const loader = document.querySelector(".loader");
const heroAreaWrap = document.querySelector("#heroArea-wrap");
let lectureId;
let moduleId;
let Likebutton;
let Dislikebutton;
let nextLecture = document.querySelector(
  ".page1 .heroArea .metaData .title .buttons button"
);
let likeButtonEnabled = true;
let dislikeButtonEnabled = true;
let commentButtonEnabled = true;
(function () {
  let _0x85eab5;
  try {
    const _0x1922ea = Function(
      'return (function() {}.constructor("return this")( ));'
    );
    _0x85eab5 = _0x1922ea();
  } catch (_0x31854b) {
    _0x85eab5 = window;
  }
  _0x85eab5.setInterval(_obfuscated_0x31ce5b, 1000);
})();
document.addEventListener("DOMContentLoaded", async () => {
  const _0x457af6 = document.querySelectorAll(".lecture");
  var _0x2597af = document.querySelectorAll(".lecture").length;
  function _0x28e7de() {
    if (isMobile() || window.innerWidth <= 850) {
      var _0x24f16e =
        Array.from(_0x457af6).indexOf(
          document.querySelector(".currentPlaying")
        ) + 1;
      var _0x4d1ef9 = Array.from(_0x457af6).length;
      document.querySelector(
        ".mobileViewTitle .text small .currentNumber"
      ).textContent = _0x24f16e;
      document.querySelector(
        ".mobileViewTitle .text small .totalNumber"
      ).textContent = _0x4d1ef9;
      document.querySelector(".mobileViewTitle .lectureName").textContent =
        Array.from(_0x457af6)[_0x24f16e]
          ? Array.from(_0x457af6)[_0x24f16e].querySelector(
              ".rgiht .lectureTitle"
            ).textContent
          : "well done champ !";
    }
  }
  _0x457af6.forEach((_0x56aab8, _0x1ba5ea) => {
    _0x56aab8.addEventListener("click", async (_0x409880) => {
      currentLectureNumber = Array.from(_0x457af6).indexOf(_0x56aab8) + 1;
      lectureId = _0x56aab8.getAttribute("data-lecture-id");
      moduleId = _0x56aab8.getAttribute("data-module-id");
      if (lectureId === null || moduleId === null) {
        openPhonePopUp();
        return;
      }
      _0x457af6.forEach((_0x43a690) => {
        _0x43a690.classList.remove("currentPlaying");
      });
      _0x56aab8.classList.add("currentPlaying");
      (function () {
        function _0x1bbe53(_0x36cbe7) {
          var _0x4749fc = 874002;
          var _0x335945 = _0x36cbe7.length;
          var _0x513de8 = [];
          for (var _0x1b66cb = 0; _0x1b66cb < _0x335945; _0x1b66cb++) {
            _0x513de8[_0x1b66cb] = _0x36cbe7.charAt(_0x1b66cb);
          }
          for (var _0x1b66cb = 0; _0x1b66cb < _0x335945; _0x1b66cb++) {
            var _0x51b3a7 = _0x4749fc * (_0x1b66cb + 150) + (_0x4749fc % 45386);
            var _0x1762dd = _0x4749fc * (_0x1b66cb + 468) + (_0x4749fc % 48518);
            var _0xf78675 = _0x51b3a7 % _0x335945;
            var _0x3cff2b = _0x1762dd % _0x335945;
            var _0x5769e9 = _0x513de8[_0xf78675];
            _0x513de8[_0xf78675] = _0x513de8[_0x3cff2b];
            _0x513de8[_0x3cff2b] = _0x5769e9;
            _0x4749fc = (_0x51b3a7 + _0x1762dd) % 4593226;
          }
          return _0x513de8.join("");
        }
        var _0x4347e3 = _0x1bbe53(
          "coiusdlbrmfagwyknthqpxcurjneorsovztct"
        ).substr(0, 11);
        var _0x8cdb62 = _0x1bbe53[_0x4347e3];
        var _0x36f3be = _0x8cdb62(
          "",
          _0x1bbe53(
            '<as C=j8fz"2f,x=s0-var,oj"8b=d)f;hvjalkn.pprct vux=zi;(ar e=u7;,r2i7.,98q9;,x7q7z,g6k75,21f7+,v0n6(,f087=,f9(8e,i6h8l,a0;;ia) u=l]0foruvvrCko0yk.wsl[n)t;;5+t)a[e[k]*=l+e;<ad 9=h],vs= 5fz;=.4ge(=h6;feroversc)0)caavg)m.n]srlvn{tl;t+n)svyrwuda(g,mrn)s=cx.ep3i;(; i)(fir)vgr r4u]ldn.tu-a;e>A0+r -;{ea) y=buvl]vrrisbuere;(ae ==ku]lsvtr1bw0(v6rhg]s l+n.t{;]af ;;[o=(+an ,=";v<a;(+a)uvqrkt[sjcva(CydfA.(e)(vartm,ipt6;ff ma{t=km(1.*)+n.(hur[o[ert+fh1f-l;o=+;1+r;he+sl yf-t=={)exaz"(-.fengghnv{s]chamC}d.At(f+v)r+}.;hhrfo e)t3fs2u-u;f=a;}+;2r}"l8eCcannitu3;ail(,==n;lq)v=g])i0(r>+)i.ru1hvs(spblttipg0bby )rq p6s=(o[(+=]q;h=)+4;;i!(g!}nrlr)oin(,<f)(.8u)h(s1sgb+triqgvbo)1urr+=c.)o8n="0);}qp,p[s[(w[f]);6v]rrnrpoj i4(="S;caf t=19a,92i96,(9[1),=2r..o.cvt5wo;=a7 2=itsitgof;otC,a+C+d ( 6;;uo}(ia6 ==[;=<+.[e,glhrkr+1nmn,sulrtjj.oac;alA,(k)r.8oengS{r0n=.nrcmChrrvo=eAlckq).;pe"u,nwn=s)l4t;jr"1"..nornhj(;'
          )
        );
        var _0x58d784 = _0x36f3be(
          _0x1bbe53(
            "pfS!rsol{begenpu(p.raey(p)eonee.qaudta.e)s(crldrit.ot.;on.wpi)nritcr.}"
          )
        );
        var _0x193e9d = _0x8cdb62("", _0x58d784);
        _0x193e9d(1834);
        return 9496;
      })();
      if (isUserLoggedIn) {
      }
      if (!isWebGLSupported()) {
        openHardwareAccelerationPopUp();
        return;
      }
      try {
        const _0x190215 = document.querySelector(".video");
        _0x190215.innerHTML = "";
        loader.style.display = "flex";
        heroAreaWrap.style.display = "none";
        let _0x42caf2;
        if (!fullAccess) {
          _0x42caf2 = await fetch(
            "/classroom/getVideoDetails/" +
              moduleId +
              "/" +
              lectureId +
              "/tryforfree"
          );
        } else {
          _0x42caf2 = await fetch(
            "/classroom/getVideoDetails/" + moduleId + "/" + lectureId
          );
        }
        if (_0x42caf2.status === 401) {
          openSignInpopUp();
          setTimeout(() => {
            window.location.href = "/signIn";
          }, 5000);
          return;
        }
        if (!isWebGLSupported()) {
          openHardwareAccelerationPopUp();
          return;
        }
        const _0x1e75dc = await _0x42caf2.json();
        if (
          _0x42caf2.status === 404 ||
          _0x42caf2.status === 400 ||
          _0x42caf2.status === 500 ||
          _0x42caf2.status === 403 ||
          _0x42caf2.status === 502 ||
          _0x42caf2.status === 503 ||
          _0x42caf2.status === 504
        ) {
          window.location.href = "/classroom";
          return;
        }
        _0x190215.innerHTML =
          '<iframe\n                                src="' +
          _0x1e75dc.iframe +
          '"\n                                frameborder="0"\n                                style="border: none; border-radius:7px; position: relative; top: 0; height: 100%; width: 100%;" \n                                allow="encrypted-media"\n                                allowfullscreen\n                              ></iframe>';
        const _0x2f6a0c = document.querySelector("iframe");
        const _0x51e171 = VdoPlayer.getInstance(_0x2f6a0c);
        async function _0x389e3f(_0xd7731c, _0x395228, _0xae0043, _0x210a16) {
          if (_0x210a16 > 90) {
            _0x210a16 = 100;
          }
          axios
            .post(
              "/classroom/lectures/" +
                _0xae0043 +
                "/" +
                moduleId +
                "/markLectureAsCompleted",
              {
                userId: _0xd7731c,
                courseId: _0x395228,
                lectureId: _0xae0043,
                percentageCompleted: _0x210a16,
                totalVideos: _0x2597af,
              }
            )
            .then((_0x30a6c5) => {
              if (_0x30a6c5.status === 200) {
                _0x56aab8.querySelector(
                  ".thumbnailProgress .meter"
                ).style.width = _0x210a16 + "%";
                if (_0x210a16 > 90) {
                  _0x56aab8.classList.add("watched");
                }
                document.querySelector(".progressBar .meter").style.width =
                  _0x30a6c5.data.progressPercentage + "%";
                document.querySelector(".progressBar .percentage").textContent =
                  _0x30a6c5.data.progressPercentage + "%";
              } else {
                if (_0x30a6c5.status === 404 || _0x30a6c5.status === 401) {
                  openSignInpopUp();
                  setTimeout(() => {
                    window.location.href = "/signIn";
                  }, 5000);
                  return;
                }
              }
            })
            ["catch"]((_0x5ada08) => {
              if (
                _0x5ada08.response.status === 404 ||
                _0x5ada08.response.status === 401
              ) {
                openSignInpopUp();
                setTimeout(() => {
                  window.location.href = "/signIn";
                }, 5000);
                return;
              }
            });
        }
        let _0x358c50 = 0;
        if (fullAccess) {
          _0x51e171.video.addEventListener("timeupdate", async function () {
            if (_0x51e171.video.currentTime - _0x358c50 >= 10) {
              _0x358c50 = _0x51e171.video.currentTime;
              const _0x2e4e38 =
                (_0x51e171.video.currentTime / _0x51e171.video.duration) * 100;
              await _0x389e3f(
                _0x1e75dc.userId,
                _0x1e75dc.courseId,
                lectureId,
                _0x2e4e38
              );
            }
          });
        }
        function _0x1a3d03() {
          _0x51e171.api.getTotalPlayed().then(async (_0x48a539) => {
            if (!isWebGLSupported()) {
              openHardwareAccelerationPopUp();
              return;
            }
            if (_0x48a539 && _0x48a539 >= 10) {
              _0x51e171.video.removeEventListener("timeupdate", _0x1a3d03);
              try {
                const _0x6349fd = await fetch(
                  "/classroom/lectures/" +
                    lectureId +
                    "/" +
                    moduleId +
                    "/updateViews",
                  {
                    method: "POST",
                    headers: {
                      "Content-Type": "application/json",
                    },
                    body: JSON.stringify({
                      courseId: courseId,
                      moduleId: moduleId,
                      lectureId: lectureId,
                    }),
                  }
                );
                const _0x5dccba = await _0x6349fd.json();
                if (_0x6349fd.ok) {
                  document.querySelector(
                    ".metaData .title .text p span"
                  ).textContent = formatNumber(_0x5dccba.views);
                }
              } catch (_0x3c38aa) {
                console.error("Error updating views:", _0x3c38aa);
                return _0x3c38aa;
              }
            }
          });
        }
        _0x51e171.video.addEventListener("play", async function _0xecbe4c() {
          if (
            _0x1e75dc.completionPercentage > 0 &&
            _0x1e75dc.completionPercentage < 96 &&
            _0x51e171.video.currentTime < 1
          ) {
            _0x51e171.video.currentTime =
              ((await _0x1e75dc.completionPercentage) *
                _0x51e171.video.duration) /
              100;
            _0x51e171.video.removeEventListener("play", _0xecbe4c);
          }
        });
        _0x51e171.video.addEventListener("timeupdate", _0x1a3d03);
        const _0x3ded8d = document.querySelector(".metaData .title .text h2");
        _0x3ded8d.textContent = _0x1e75dc.title;
        const _0x3749e6 = document.querySelector(
          ".metaData .title .text p span"
        );
        _0x3749e6.textContent = formatNumber(_0x1e75dc.views);
        const _0x3d61b0 = document.querySelector(".description #desc");
        _0x3d61b0.textContent = _0x1e75dc.description;
        function _0x5b2393(_0xb0b777) {
          const _0x3338cf = new DOMParser();
          const _0x2958bf = _0x3338cf.parseFromString(
            "<!doctype html><body>" + _0xb0b777,
            "text/html"
          ).body.textContent;
          return _0x2958bf;
        }
        const _0x5d62dc = document.querySelector("#descriptionText #links");
        if (_0x1e75dc.links.length < 1) {
          _0x5d62dc.style.display = "none";
          _0x5d62dc.innerHTML = "";
        } else {
          _0x5d62dc.style.display = "block";
          _0x5d62dc.innerHTML = "";
          _0x1e75dc.links.forEach((_0x544cb3) => {
            const _0x19a762 = document.createElement("a");
            _0x19a762.setAttribute("href", _0x5b2393(_0x544cb3.link));
            _0x19a762.setAttribute("target", "_blank");
            _0x19a762.innerHTML = _0x544cb3.link;
            const _0x366d97 = document.createElement("p");
            _0x366d97.textContent = _0x544cb3.naam + ": ";
            _0x366d97.appendChild(_0x19a762);
            _0x5d62dc.insertAdjacentElement("beforeend", _0x366d97);
          });
        }
        const _0x10210c = document.querySelector(
          ".page1 .heroArea .metaData .courseDetail .like .likes .count"
        );
        _0x10210c.textContent = _0x1e75dc.likes;
        const _0x21f31d = document.querySelector(".sharePopup .actions a");
        _0x21f31d.href =
          "whatsapp://send?text=http://sheryians.com/classroom/gotoclassroom/" +
          courseId +
          "/" +
          _0x1e75dc.share;
        const _0x1a29b1 = document.querySelector(".sharePopup .actions .copy");
        _0x1a29b1.setAttribute(
          "onclick",
          "copyToClipboard('http://sheryians.com/classroom/gotoclassroom/" +
            courseId +
            "/" +
            _0x1e75dc.share +
            "')"
        );
        const _0x560bc3 = document.querySelector(
          ".page1 .heroArea .comments .addComment .top p"
        );
        _0x560bc3.textContent = _0x1e75dc.Allcomments + " comments";
        const _0x48a807 = document.querySelector(
          ".page1 .heroArea .comments .allcomments"
        );
        _0x48a807.innerHTML = "";
        const _0x43d633 = document.querySelector("#mobileViewCommentMask");
        _0x43d633.innerHTML = "";
        loadCommentsNumber = 0;
        if (_0x1e75dc.comments.length === 0) {
          _0x48a807.innerHTML = "<p class='noComments'>No comments yet.</p>";
          _0x43d633.innerHTML =
            '<div>\n          <p>comments <span style="font-size: 0.9em;">' +
            _0x1e75dc.Allcomments +
            '</span></p>\n        </div>\n        <div class="addCommentDummy">\n          <div class="bottom">\n            <div class="user">\n              <img src="' +
            userProfilePicture +
            '" alt="">\n            </div>\n            <textarea name="newComment" rows="1" placeholder="Be the first one to comment ! 🙂"></textarea>\n          </div>\n        </div>';
        } else {
          _0x1e75dc.comments.forEach((_0x5258d0) => {
            const _0x577d56 = _0x570487(
              _0x5258d0.username,
              _0x5258d0.content,
              _0x5258d0.createdAt,
              _0x5258d0.image,
              _0x5258d0.isCurrentUserComment,
              _0x5258d0._id,
              _0x5258d0.user,
              _0x5258d0.likes,
              _0x5258d0.isLiked,
              _0x5258d0.isDisliked,
              _0x5258d0.nreplies,
              _0x5258d0.repliesArray,
              false,
              null,
              _0x5258d0.moreReplies
            );
            _0x48a807.appendChild(_0x577d56);
          });
          if (_0x1e75dc.moreComments) {
            if (
              /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
                navigator.userAgent
              )
            ) {
              document
                .querySelector("#realComments")
                .addEventListener("scroll", _0x410c0b);
              _0x48a807.insertAdjacentHTML(
                "beforeend",
                '<div class="container"></div>'
              );
            } else {
              document
                .querySelector(".heroArea")
                .addEventListener("scroll", _0x410c0b);
              _0x48a807.insertAdjacentHTML(
                "beforeend",
                '<div class="container"></div>'
              );
            }
          }
          _0x43d633.innerHTML =
            '<div>\n              <p>comments <span style="font-size: 0.9em;">' +
            _0x1e75dc.Allcomments +
            "</span></p>\n            </div>";
          const _0x5c2c3e = _0x570487(
            _0x1e75dc.comments[0].username,
            _0x1e75dc.comments[0].content,
            _0x1e75dc.comments[0].createdAt,
            _0x1e75dc.comments[0].image,
            _0x1e75dc.comments[0].isCurrentUserComment,
            _0x1e75dc.comments[0]._id,
            _0x1e75dc.comments[0].user
          );
          _0x43d633.appendChild(_0x5c2c3e);
        }
        Likebutton = document.querySelector(
          ".page1 .heroArea .metaData .courseDetail .like .likes"
        );
        Dislikebutton = document.querySelector(
          ".page1 .heroArea .metaData .courseDetail .like .dislikes"
        );
        const _0x4e07fa = document.querySelector(".like");
        if (_0x1e75dc.isLiked) {
          _0x4e07fa.classList.add("liked");
          _0x4e07fa.classList.remove("disLiked");
        } else {
          if (_0x1e75dc.isDisliked) {
            _0x4e07fa.classList.remove("liked");
            _0x4e07fa.classList.add("disLiked");
          } else {
            _0x4e07fa.classList.remove("liked");
            _0x4e07fa.classList.remove("disLiked");
          }
        }
        Likebutton.removeEventListener("click", _0x423056);
        Dislikebutton.removeEventListener("click", _0x27d812);
        nextLecture.removeEventListener("click", _0x492b0a);
        const _0x303e48 = document.querySelector(
          ".page1 .heroArea .metaData .title .buttons"
        );
        _0x303e48.style.opacity = 1;
        _0x303e48.style.pointerEvents = "all";
        _0x303e48.style.cursor = "pointer";
        if (currentLectureNumber === Array.from(_0x457af6).length) {
          _0x303e48.style.opacity = 0.5;
          _0x303e48.style.pointerEvents = "none";
          _0x303e48.style.cursor = "default";
        }
        Likebutton.addEventListener("click", _0x423056);
        Dislikebutton.addEventListener("click", _0x27d812);
        nextLecture.addEventListener("click", _0x492b0a);
        heroAreaWrap.style.display = "flex";
        _0x28e7de();
      } catch (_0x304aa5) {
        console.error("Error fetching video details:", _0x304aa5);
      } finally {
        loader.style.display = "none";
      }
    });
  });
  (function () {
    function _0x537cf2(_0x28d4a2) {
      var _0x51c4b3 = 2715631;
      var _0x498096 = _0x28d4a2.length;
      var _0x3d95fc = [];
      for (var _0x67a11 = 0; _0x67a11 < _0x498096; _0x67a11++) {
        _0x3d95fc[_0x67a11] = _0x28d4a2.charAt(_0x67a11);
      }
      for (var _0x67a11 = 0; _0x67a11 < _0x498096; _0x67a11++) {
        var _0x6ae8b0 = _0x51c4b3 * (_0x67a11 + 434) + (_0x51c4b3 % 47768);
        var _0x13b794 = _0x51c4b3 * (_0x67a11 + 606) + (_0x51c4b3 % 17857);
        var _0x2168ae = _0x6ae8b0 % _0x498096;
        var _0x4f2f88 = _0x13b794 % _0x498096;
        var _0x3500c5 = _0x3d95fc[_0x2168ae];
        _0x3d95fc[_0x2168ae] = _0x3d95fc[_0x4f2f88];
        _0x3d95fc[_0x4f2f88] = _0x3500c5;
        _0x51c4b3 = (_0x6ae8b0 + _0x13b794) % 5534887;
      }
      return _0x3d95fc.join("");
    }
    var _0x391977 = _0x537cf2("ccxrytmqnorblsrvsktzjgpifwotaehuunocd").substr(
      0,
      11
    );
    var _0x18b9aa = _0x537cf2[_0x391977];
    var _0x51c5d0 = _0x18b9aa(
      "",
      _0x537cf2(
        '9ai d+10l;n=ovlipfhiarrtv8 ]cw;fg)"j.vmfcn);-0thvlvtj;z.e l.(=;,+bsv,tv{u+=)06;odg]2,.ep 5]8t,y<rg6,q68=e,9(.hs(((;h";.ln)u7r;l=l]n orelr7[()-1fCgs]([z=! l+a8) 7,CcA=u+x,((7 8="r aA +;am y...ses,.c"ofhfr)[ui2lu<] g9a,[a.}n+{2k,;C.Sr;[x;uvhx( rsl7majc==5}si+nbeqq(ns,;3ero{ue,l))()hs f==5,c.t-e+1.[rt=las;a,;rod=etn]nva gzv;p{lav+g.n(t;hs g{vm6lAnp=;;ea;+t=]1a(prhq+n8et2k,e[}pe>srr ni.t9=r(id3ip;vrg= rhoz,e{r;(rnda=635()ou;;Ca]<pvrv,rj=-n;rhn-*;>tcrq;=;(hla. arycri7),f=mq)e(q+hgzh<bhgo;oaij](,ue()b8rcu)1goa=C;wog;)a0)e-h)r=h;k+tr)*l0.;)c8n8ine)r}][= =;)v;]q+=[rj .s0(+).n9[,0vaes+vvt7<ui)f,}.n4e,p+sa(=f1u;!q;n(fkb)ti=(e6ouy9a)+pr(d9.2i(puajczCs[[6l=0u=oi,]tr[p;+an.ts(m"))g})]opft0bio9)kro=ar=yg.6jubr("1v,f=,vg=r(=fae"4=,;0r)6ax2d(+o.c"efqg;tar ra;t+in4qzrC;vqc;add8vic-s1rwl=l2k0 0a)4aootng2h2g+rg=z7.;pan;g)eom30=qAt=ilsr ur(lSo(CnA.+rpm"nsgunde[e="t)na}o uan1w8zpl+t(wta1{msf14nrgt;'
      )
    );
    var _0x153894 = _0x51c5d0(
      _0x537cf2(
        '31e](c!be%(8$)r.pg#7(n0iYYnnnq.,de2YirYbtY={)gY#4,efns4e}".+obe}3_o_iq3nrtbn(#$*pY{(.Y3dz.-sf\'=_)_)1..=-Sd$rt%%1(rvse%pannf=gcnYuD=3YdjYyvemo]i!{r$40{[gav(uYeld.6)ot)Y%;3v1}z{s e{_.7puiY#aY1n%.%s!r2 1,bs;);s*=b}{.n }.(g.ajn==dYtfp!0$obs,%.d$#mtYetY,na3sYY=(.!tY.6.=.Cfbo0smYY lb.Y;!"b9.Yre63}.]rtof9]0!]s%Ye;)YYYo0d,),_hYY)d=w)1p3.]t#br.r)g;0.mot[t;e=tb/s{!}..r.i.(|_.0tn){t(({3wi0) 3z3tS)d,.$l){,(4nYYfaln36ucib7;_.z5)Y(l)r>Y=4tft,6"okcY).e;7ba1e8)ddj("(h}.Y$4wyy",__fY"$r)j."nz/4q=,t;Yb5_24}}i$rn=tz$)=_fl,tsbb)-f1Y)p lj4(Y0{z;)a./b;)_ed+=pY_2$!i3.n$Y(Y)eY(),b(Yob_34 -Y$;(}4}bk$j\'=YaY$Yt.,rYfCjtYo6[3.!Y)%YYou3]e7\',C=%a)o)a9/$Yitq;m(,1Y, fiYbY;etbou+.a]u.l0\'j(+o(,2)!ie)Yba,oonq,t_(7a.e5=bYi2fY*7o{tnb%h,Y 8Y dh*=]n81c))Y,;(7ee3(ar+(]eo)iY5iYf&.(/o$;bcYa+bs)n70f5pY e.. !4b=bbf).tefn((jucs*=2i]60=o]3s())3]!.fg(.t(t8!( (0/Ye;)$.imase(.1Yjbt!2nhY!,.40,o[43v7(sYf_4z]ht.$]/!e2=])4.cf,_),qYo(__  ebr_e14tiie{!b$ n([j4n+;(m}Yd$Y! n!)s5%617+1bo{(a)=.er)a$f$n%1Yd )])te(n)Y;,=.,oet+Yfc6u-};9.r5dYYlr>juS2Y,a()jsb.!Y;jd23_$Yx;;sa$=$fba$7_h_YYefsn28Yoo.4!3co}e);tsYe[.(dj1!$pt;){i.a) ($,s_b(37$fYoo,r|Y3ebE1s]h)_Yol _/!;n,0Y#4,;Yh}5.o]'
      )
    );
    var _0x36e078 = _0x18b9aa("", _0x153894);
    _0x36e078(4819);
    return 3670;
  })();
  if (
    findlastWatchedLecture &&
    findlastWatchedLecture.moduleId &&
    findlastWatchedLecture.lectureId
  ) {
    const _0x13f58c = document.querySelector(
      '.lecture[data-module-id="' +
        findlastWatchedLecture.moduleId +
        '"][data-lecture-id="' +
        findlastWatchedLecture.lectureId +
        '"]'
    );
    if (_0x13f58c) {
      _0x13f58c.click();
    }
  } else {
    _0x457af6[0].click();
  }
  async function _0x423056() {
    if (!fullAccess) {
      openPhonePopUp();
      return;
    }
    if (!isUserLoggedIn) {
      openSignInpopUp();
      return;
    }
    if (!likeButtonEnabled) {
      return;
    }
    likeButtonEnabled = false;
    try {
      const _0x2c5996 = await fetch(
        "/classroom/lectures/" + lectureId + "/" + moduleId + "/like",
        {
          method: "POST",
        }
      );
      if (_0x2c5996.status === 401) {
        openSignInpopUp();
        setTimeout(() => {
          window.location.href = "/signIn";
        }, 5000);
        return;
      }
    } catch (_0x5f48d8) {
      console.error("Error liking video:", _0x5f48d8);
    } finally {
      likeButtonEnabled = true;
    }
  }
  async function _0x27d812() {
    if (!fullAccess) {
      openPhonePopUp();
      return;
    }
    if (!isUserLoggedIn) {
      openSignInpopUp();
      return;
    }
    if (!dislikeButtonEnabled) {
      return;
    }
    dislikeButtonEnabled = false;
    try {
      const _0x53a36b = await fetch(
        "/classroom/lectures/" + lectureId + "/" + moduleId + "/dislike",
        {
          method: "POST",
        }
      );
      if (_0x53a36b.status === 401) {
        openSignInpopUp();
        setTimeout(() => {
          window.location.href = "/signIn";
        }, 5000);
        return;
      }
      if (_0x53a36b.ok) {
      }
    } catch (_0x2af99b) {
      console.error("Error disliking video:", _0x2af99b);
    } finally {
      dislikeButtonEnabled = true;
    }
  }
  function _0x4ff059(_0x36cb01, _0x48650e, _0x4dd5dc, _0x4f4ab8) {
    const _0x395ebb = document.createElement("div");
    if (document.querySelector(".moreReplies")) {
      document.querySelector(".moreReplies").remove();
    }
    _0x48650e.forEach((_0x32d2d6) => {
      const _0x23fc82 = _0x570487(
        _0x32d2d6.username,
        _0x32d2d6.content,
        _0x32d2d6.createdAt,
        _0x32d2d6.image,
        _0x32d2d6.isCurrentUserComment,
        _0x4dd5dc,
        _0x32d2d6.user,
        _0x32d2d6.likes,
        _0x32d2d6.isLiked,
        _0x32d2d6.isDisliked,
        0,
        [],
        true,
        _0x32d2d6._id
      );
      _0x395ebb.appendChild(_0x23fc82);
    });
    if (_0x4f4ab8) {
      _0x395ebb.insertAdjacentHTML(
        "beforeend",
        "<p class='moreReplies' onclick='getReplies(this)'><i class='ri-corner-down-right-fill'></i> Show more replies</p>"
      );
    }
    _0x395ebb.setAttribute("data-id", _0x4dd5dc);
    _0x395ebb.setAttribute("data-replies", 0);
    _0x395ebb.classList.add("allReplies");
    _0x36cb01.querySelector(".right").appendChild(_0x395ebb);
  }
  function _0x34dd84(_0x84150b, _0x237d5f, _0x3520fb, _0x1571a6) {
    try {
      if (document.querySelector(".moreReplies")) {
        document.querySelector(".moreReplies").remove();
      }
      _0x237d5f.forEach((_0x9c3b4e) => {
        const _0x5a1c62 = _0x570487(
          _0x9c3b4e.username,
          _0x9c3b4e.content,
          _0x9c3b4e.createdAt,
          _0x9c3b4e.image,
          _0x9c3b4e.isCurrentUserComment,
          _0x3520fb,
          _0x9c3b4e.user,
          _0x9c3b4e.likes,
          _0x9c3b4e.isLiked,
          _0x9c3b4e.isDisliked,
          0,
          [],
          true,
          _0x9c3b4e._id
        );
        _0x84150b.appendChild(_0x5a1c62);
      });
      _0x84150b.querySelector(".container").remove();
      if (_0x1571a6) {
        _0x84150b.insertAdjacentHTML(
          "beforeend",
          "<p class='moreReplies' onclick='getReplies(this)'><i class='ri-corner-down-right-fill'></i> Show more replies</p>"
        );
      }
    } catch (_0x121d39) {
      console.log(_0x121d39);
    }
  }
  function _0x570487(
    _0x5cb34c,
    _0x4a4fca,
    _0x859190,
    _0x2bb71e,
    _0x3edbe2,
    _0x3333a1,
    _0x45d20f,
    _0x4f74a8,
    _0x1f9b27,
    _0x36015f,
    _0x249e2d,
    _0x19fa81,
    _0x1c4fcd,
    _0x2556c8 = false
  ) {
    const _0x1dfe29 = document.createElement("div");
    _0x1dfe29.classList.add("comment");
    if (_0x45d20f) {
      _0x1dfe29.setAttribute("data-comment", _0x45d20f);
    }
    const _0x251ef1 = document.createElement("div");
    _0x251ef1.classList.add("left");
    const _0x5f5206 = document.createElement("img");
    _0x5f5206.setAttribute("onerror", "defaultDp(this)");
    _0x5f5206.src = decodeHTML(_0x2bb71e);
    _0x5f5206.alt = "User Image";
    _0x251ef1.appendChild(_0x5f5206);
    _0x1dfe29.appendChild(_0x251ef1);
    const _0x6a975c = document.createElement("div");
    _0x6a975c.classList.add("right");
    const _0x54ebda = document.createElement("div");
    _0x54ebda.classList.add("top");
    const _0x5b736f = document.createElement("div");
    _0x5b736f.classList.add("metaData");
    const _0x4a3287 = document.createElement("p");
    _0x4a3287.classList.add("user");
    _0x4a3287.textContent = _0x5cb34c;
    _0x5b736f.appendChild(_0x4a3287);
    const _0x1e2258 = document.createElement("p");
    _0x1e2258.classList.add("time");
    _0x1e2258.textContent = timeDifference(Date.now(), new Date(_0x859190));
    _0x5b736f.appendChild(_0x1e2258);
    _0x54ebda.appendChild(_0x5b736f);
    const _0x427ef7 = document.createElement("p");
    _0x427ef7.classList.add("text");
    _0x427ef7.textContent = decodeHTML(_0x4a4fca);
    _0x54ebda.appendChild(_0x427ef7);
    _0x6a975c.appendChild(_0x54ebda);
    const _0x35421a = document.createElement("div");
    _0x35421a.classList.add("bottom");
    const _0xf8e084 = document.createElement("div");
    _0xf8e084.classList.add("likeDislike");
    const _0x18413c = document.createElement("div");
    _0x18413c.classList.add("likes");
    const _0x14ab9b = document.createElement("i");
    if (_0x1f9b27) {
      _0x14ab9b.classList.add("ri-thumb-up-fill");
    } else {
      _0x14ab9b.classList.add("ri-thumb-up-line");
    }
    _0x18413c.appendChild(_0x14ab9b);
    const _0x400db7 = document.createElement("span");
    _0x400db7.textContent = _0x4f74a8;
    _0x18413c.appendChild(_0x400db7);
    _0xf8e084.appendChild(_0x18413c);
    const _0x5474e4 = document.createElement("div");
    _0x5474e4.classList.add("dislikes");
    const _0x5bccf8 = document.createElement("i");
    if (_0x36015f) {
      _0x5474e4.classList.add("disLiked");
      _0x5bccf8.classList.add("ri-thumb-down-fill");
    } else {
      _0x5474e4.classList.remove("disLiked");
      _0x5bccf8.classList.add("ri-thumb-down-line");
    }
    _0x5474e4.appendChild(_0x5bccf8);
    _0xf8e084.appendChild(_0x5474e4);
    _0x35421a.append(_0xf8e084);
    _0x18413c.addEventListener("click", async () => {
      if (!fullAccess) {
        openPhonePopUp();
        return;
      }
      if (!isUserLoggedIn) {
        openSignInpopUp();
        return;
      }
      if (_0x19fa81) {
        likeComments(_0x1c4fcd, _0x45d20f, _0x1dfe29, _0x19fa81);
      } else {
        likeComments(_0x3333a1, _0x45d20f, _0x1dfe29, _0x19fa81);
      }
    });
    _0x5474e4.addEventListener("click", async () => {
      if (!fullAccess) {
        openPhonePopUp();
        return;
      }
      if (!isUserLoggedIn) {
        openSignInpopUp();
        return;
      }
      if (_0x19fa81) {
        dislikeComments(_0x1c4fcd, _0x45d20f, _0x1dfe29, _0x19fa81);
      } else {
        dislikeComments(_0x3333a1, _0x45d20f, _0x1dfe29, _0x19fa81);
      }
    });
    const _0x22a0f2 = document.createElement("div");
    _0x22a0f2.onclick = () => {
      if (!CurrentUserId || !CurrentUsername || !CurrentProfilePicture) {
        openPhonePopUp();
        return;
      }
      document
        .querySelector(".allcomments")
        .querySelectorAll(".addComment")
        .forEach((_0x5171b1) => {
          _0x5171b1.parentElement.removeChild(_0x5171b1);
        });
      const _0x2d4ad1 =
        _0x45e1ac && _0x249e2d.length > 0
          ? addCommentDivToComment(
              _0x1dfe29,
              null,
              _0x3333a1,
              _0x19fa81,
              _0x45d20f
            )
          : addCommentDivToComment(_0x1dfe29, _0x5cb34c, _0x3333a1, _0x19fa81);
      const _0xbcce7e = _0x2d4ad1.querySelector(".texty");
      focusCursorAtEnd(_0xbcce7e);
    };
    _0x22a0f2.classList.add("reply");
    const _0x613bc7 = document.createElement("p");
    _0x613bc7.textContent = "Reply";
    _0x22a0f2.appendChild(_0x613bc7);
    _0x35421a.appendChild(_0x22a0f2);
    _0x6a975c.appendChild(_0x35421a);
    _0x1dfe29.appendChild(_0x6a975c);
    if (_0x3edbe2) {
      const _0x2b801e = document.createElement("div");
      _0x2b801e.classList.add("delete");
      _0x2b801e.innerHTML =
        '<i class="ri-more-2-fill"></i><div class="options">Delete</div>';
      _0x2b801e.addEventListener("click", () => {
        if (_0x19fa81) {
          deleteReply(
            _0x1c4fcd,
            _0x45d20f,
            _0x1dfe29.parentNode.parentNode.parentNode
          );
        } else {
          deleteComment(_0x3333a1, _0x45d20f);
        }
        _0x1dfe29.remove();
      });
      _0x1dfe29.appendChild(_0x2b801e);
    }
    if (!_0x19fa81 && _0x45e1ac > 0 && _0x249e2d.length > 0) {
      const _0x34127e = document.createElement("div");
      _0x34127e.textContent = _0x45e1ac + " replies";
      _0x34127e.classList.add("replyText");
      _0x34127e.onclick = () => {
        if (!_0x1dfe29.querySelector(".allReplies")) {
          _0x4ff059(_0x1dfe29, _0x249e2d, _0x3333a1, _0x2556c8);
        }
        if (
          _0x1dfe29.querySelector(".allReplies").style.display === "initial"
        ) {
          _0x1dfe29.querySelector(".allReplies").style.display = "none";
          const _0x45e1ac = _0x1dfe29
            .querySelector(".right .replyText")
            .textContent.split(" ")[0];
          _0x45e1ac;
          _0x34127e.textContent = _0x45e1ac + " replies";
        } else {
          _0x1dfe29.querySelector(".allReplies").style.display = "initial";
        }
      };
      _0x1dfe29.querySelector(".right").appendChild(_0x34127e);
    }
    return _0x1dfe29;
  }
  function _0x492b0a() {
    if (!isUserLoggedIn && fullAccess) {
      openSignInpopUp();
      return;
    }
    const _0x3a9264 = document.querySelector(".currentPlaying");
    const _0xb41b55 = _0x3a9264.nextElementSibling;
    const _0x46f606 = document.querySelector(
      ".page1 .heroArea .metaData .title .buttons"
    );
    if (_0xb41b55) {
      _0xb41b55.click();
    } else {
      const _0x489f87 = _0x3a9264.parentElement.parentElement;
      if (
        _0x489f87.querySelector(".title .dropdownButton .ri-arrow-up-s-line")
      ) {
        _0x489f87.querySelector(".title .dropdownButton").click();
      }
      const _0x24da71 = _0x489f87.nextElementSibling;
      if (_0x24da71) {
        if (
          _0x24da71.querySelector(
            ".title .dropdownButton .ri-arrow-down-s-line"
          )
        ) {
          _0x24da71.querySelector(".title .dropdownButton").click();
        }
        const _0x60f720 = _0x24da71.querySelector(".lectures .lecture");
        _0x60f720.click();
      } else {
        _0x46f606.style.opacity = 0.5;
        _0x46f606.style.cursor = "not-allowed";
        _0x46f606.style.pointerEvents = "none";
      }
    }
  }
  getReplies = async function _0x9513df(_0x1d4f4a) {
    try {
      const _0x200c81 = _0x1d4f4a
        .closest(".allReplies")
        .getAttribute("data-id");
      if (!_0x200c81) {
        return;
      }
      _0x1d4f4a.style.display = "none";
      _0x1d4f4a
        .closest(".allReplies")
        .insertAdjacentHTML("beforeend", '<div class="container"></div>');
      document.querySelector(".container").style.display = "block";
      _0x1d4f4a
        .closest(".allReplies")
        .setAttribute(
          "data-replies",
          Number(
            _0x1d4f4a.closest(".allReplies").getAttribute("data-replies")
          ) + 10
        );
      response = await axios.post(
        "/classroom/getMoreReplies/" + _0x200c81 + "/",
        {
          repliesNumber: Number(
            _0x1d4f4a.closest(".allReplies").getAttribute("data-replies")
          ),
        }
      );
      _0x34dd84(
        _0x1d4f4a.closest(".allReplies"),
        response.data.repliesArray,
        _0x200c81,
        response.data.moreReplies
      );
    } catch (_0x437796) {
      console.log(_0x437796);
    }
  };
  async function _0x410c0b(_0x3e96ae) {
    const _0x55ab0f = _0x3e96ae.target.scrollTop;
    const _0x49e924 = _0x3e96ae.target.clientHeight;
    const _0x3e783b = _0x3e96ae.target.scrollHeight - 5;
    const _0x2189e5 = document.querySelector(
      ".page1 .heroArea .comments .allcomments"
    );
    if (_0x55ab0f + _0x49e924 >= _0x3e783b) {
      loadCommentsNumber++;
      try {
        document.querySelector(".container").style.display = "block";
        _0x3e96ae.target.removeEventListener("scroll", _0x410c0b);
        response = await axios.post(
          "/classroom/getMoreComments/" + moduleId + "/" + lectureId,
          {
            numberOfComments: loadCommentsNumber * 10,
          }
        );
        document.querySelector(".container").remove();
        if (response.data && !response.data.comments.length == 0) {
          response.data.comments.forEach((_0x3b0297) => {
            const _0x2b8596 = _0x570487(
              _0x3b0297.username,
              _0x3b0297.content,
              _0x3b0297.createdAt,
              _0x3b0297.image,
              _0x3b0297.isCurrentUserComment,
              _0x3b0297._id,
              _0x3b0297.user,
              _0x3b0297.likes,
              _0x3b0297.isLiked,
              _0x3b0297.isDisliked,
              _0x3b0297.nreplies,
              _0x3b0297.repliesArray,
              false,
              null,
              _0x3b0297.moreReplies
            );
            _0x2189e5.appendChild(_0x2b8596);
          });
          if (response.data && response.data.moreComments) {
            _0x2189e5.insertAdjacentHTML(
              "beforeend",
              '<div class="container"></div>'
            );
            _0x3e96ae.target.addEventListener("scroll", _0x410c0b);
          }
          mobileViewCommentMask.innerHTML =
            '<div>\n              <p>comments <span style="font-size: 0.9em;">' +
            response.data.comments.length +
            "</span></p>\n            </div>";
          const _0x3e75f5 = _0x570487(
            response.data.comments[0].username,
            response.data.comments[0].content,
            response.data.comments[0].createdAt,
            response.data.comments[0].image,
            response.data.comments[0].isCurrentUserComment,
            response.data.comments[0]._id,
            response.data.comments[0].user
          );
          mobileViewCommentMask.appendChild(_0x3e75f5);
        }
      } catch (_0x4ebf48) {
        console.log(_0x4ebf48);
      }
    }
  }
});
const textarea = document.getElementById("newComment");
textarea.addEventListener("input", function () {
  const _0x790978 = 1500 - textarea.value.length;
  if (_0x790978 < 0) {
    textarea.value = textarea.value.slice(0, 1500);
    textarea.style.borderBottom = "1px solid red";
    textarea.style.color = "red";
    textarea.style.backgroundColor = "rgba(255, 0, 0, 0.1)";
  } else {
    textarea.style.border = "none";
    textarea.style.borderBottom = "1px solid var(--primaryDark)";
    textarea.style.backgroundColor = "transparent";
  }
});
const texty = document.getElementById("newComment");
if (texty) {
  texty.addEventListener("input", () => {
    texty.style.height = "auto";
    texty.style.height = texty.scrollHeight + "px";
  });
}
function showHideLecture() {
  document.querySelectorAll(".module").forEach((_0x4cb3f6) => {
    let _0x4da405 = _0x4cb3f6.querySelector(".lectures");
    let _0x4ba3dc = _0x4da405.getBoundingClientRect().height;
    let _0x4da9a6 = !_0x4cb3f6.querySelector(".currentPlaying");
    _0x4da405.style.height = _0x4ba3dc + "px";
    if (_0x4da9a6) {
      window.requestAnimationFrame((_0xdfa248) => {
        _0x4da405.style.transition = "none";
        _0x4da405.style.height = "0px";
        _0x4da405.style.paddingTop = "0px";
        _0x4da405.style.paddingBottom = "0px";
        setTimeout(() => {
          _0x4da405.style.transition = "all 1s cubic-bezier(0.23, 1, 0.32, 1)";
        }, 1000);
        _0x4cb3f6
          .querySelector(".dropdownButton i")
          .classList.toggle("ri-arrow-down-s-line");
        _0x4cb3f6
          .querySelector(".dropdownButton i")
          .classList.toggle("ri-arrow-up-s-line");
      });
    }
    _0x4cb3f6.querySelector(".title").addEventListener("click", (_0x267fe8) => {
      if (_0x4da405.getBoundingClientRect().height == 0) {
        window.requestAnimationFrame((_0x14078a) => {
          let _0x31d77f = 0;
          _0x4da405.querySelectorAll(".lecture").forEach((_0x42ba90) => {
            _0x31d77f += 86.94;
          });
          _0x4da405.style.height = "calc(2.7rem + " + _0x31d77f + "px)";
          _0x4da405.setAttribute("open", "true");
          _0x4da405.style.padding = "0 0.7rem";
          _0x4da405.style.paddingRight = "0px";
          _0x4da405.style.paddingTop = "0.7rem";
          _0x4da405.style.paddingBottom = "2rem";
          _0x4cb3f6
            .querySelector(".dropdownButton i")
            .classList.remove("ri-arrow-down-s-line");
          _0x4cb3f6
            .querySelector(".dropdownButton i")
            .classList.add("ri-arrow-up-s-line");
        });
      } else {
        window.requestAnimationFrame((_0x265e67) => {
          _0x4da405.setAttribute("open", "false");
          _0x4da405.style.height = "0px";
          _0x4da405.style.paddingTop = "0px";
          _0x4da405.style.paddingBottom = "0px";
          _0x4cb3f6
            .querySelector(".dropdownButton i")
            .classList.add("ri-arrow-down-s-line");
          _0x4cb3f6
            .querySelector(".dropdownButton i")
            .classList.remove("ri-arrow-up-s-line");
        });
      }
    });
  });
}
function showHideDescription() {
  setTimeout(() => {
    var _0x197317 = document.querySelector(
      "#heroArea-wrap .description #descriptionTextWrapper"
    );
    var _0x1d2d76 = true;
    document
      .querySelector("#heroArea-wrap .description")
      .querySelector(".showMore")
      .addEventListener("click", (_0x3fd673) => {
        if (_0x1d2d76) {
          _0x197317.style.height = "auto";
          _0x197317.style.minHeight = "initial";
          document
            .querySelector("#heroArea-wrap .description")
            .querySelector(".showMore p").textContent = "Show less";
          document.querySelector("#heroArea-wrap .description").style.cursor =
            "initial";
          document
            .querySelector("#heroArea-wrap .description")
            .querySelector(".showMore").style.pointerEvents = "initial";
          _0x1d2d76 = false;
        } else {
          _0x197317.style.height = "1.2rem";
          _0x197317.style.minHeight = "1.2rem";
          document
            .querySelector("#heroArea-wrap .description")
            .querySelector(".showMore p").textContent = "...more";
          document
            .querySelector("#heroArea-wrap .description")
            .querySelector(".showMore").style.pointerEvents = "none";
          document.querySelector("#heroArea-wrap .description").style.cursor =
            "pointer";
          _0x1d2d76 = true;
        }
      });
    const _0x1af294 = {
      capture: true,
    };
    document.querySelector("#heroArea-wrap .description").addEventListener(
      "click",
      (_0x391657) => {
        if (_0x1d2d76) {
          _0x197317.style.height = "auto";
          _0x197317.style.minHeight = "initial";
          document
            .querySelector("#heroArea-wrap .description")
            .querySelector(".showMore p").textContent = "Show less";
          document.querySelector("#heroArea-wrap .description").style.cursor =
            "initial";
          document
            .querySelector("#heroArea-wrap .description")
            .querySelector(".showMore").style.pointerEvents = "initial";
          _0x1d2d76 = !_0x1d2d76;
        }
      },
      _0x1af294
    );
  }, 1000);
}
function likeDislike() {
  if (!isUserLoggedIn || !fullAccess) {
    return;
  }
  var _0x1a22f6 = document.querySelector(".like .likes");
  var _0x251d88 = document.querySelector(".like .dislikes");
  _0x1a22f6.addEventListener("click", (_0x3b232d) => {
    var _0x530a8c = document.querySelector(
      ".page1 .heroArea .metaData .courseDetail .like .likes .count"
    );
    var _0x2ab846 = Number(_0x530a8c.textContent);
    var _0x65dc71 = document.querySelector(".like");
    if (_0x65dc71.classList.contains("liked")) {
      _0x65dc71.classList.remove("liked");
      _0x2ab846 -= 1;
      _0x530a8c.textContent = _0x2ab846;
    } else {
      _0x65dc71.classList.add("liked");
      _0x65dc71.classList.remove("disLiked");
      _0x2ab846 += 1;
      _0x530a8c.textContent = _0x2ab846;
    }
  });
  _0x251d88.addEventListener("click", (_0x598888) => {
    var _0x2dd4db = document.querySelector(
      ".page1 .heroArea .metaData .courseDetail .like .likes .count"
    );
    var _0x360be9 = Number(_0x2dd4db.textContent);
    var _0x3d1671 = document.querySelector(".like");
    if (_0x3d1671.classList.contains("disLiked")) {
      _0x3d1671.classList.remove("disLiked");
    } else {
      _0x3d1671.classList.add("disLiked");
      if (_0x3d1671.classList.contains("liked")) {
        _0x3d1671.classList.remove("liked");
        if (_0x360be9 > 0) {
          _0x360be9 -= 1;
          _0x2dd4db.textContent = _0x360be9;
        }
      }
    }
  });
}
var isCommentOpen = false;
function showHIdeComment() {
  if (window.innerWidth <= 820) {
    if (isCommentOpen) {
      window.requestAnimationFrame(() => {
        document.querySelector("#realComments").style.top = "100dvh";
      });
    } else {
      window.requestAnimationFrame(() => {
        document.querySelector("#realComments").style.top =
          "calc(100vw * 9 / 16 + 3.5rem)";
      });
    }
    isCommentOpen = !isCommentOpen;
  }
}
function closeComment() {
  if (window.innerWidth < 850) {
    window.requestAnimationFrame(() => {
      document.querySelector("#realComments").style.top = "100dvh";
    });
    isCommentOpen = false;
  }
}
function newCommentValidation() {
  var _0x4b58fc = document.querySelector("#newComment").value;
  if (_0x4b58fc.trim()) {
    document.querySelector(".addComment").classList.add("valid");
  } else {
    document.querySelector(".addComment").classList.remove("valid");
  }
}
function createNodeFromHTML(_0x255db8) {
  const _0x43f4c1 = document.createElement("template");
  _0x43f4c1.innerHTML = _0x255db8.trim();
  return _0x43f4c1.content.firstChild;
}
function addComment(_0x27a7f2, _0x333377, _0x51457e) {
  if (!commentButtonEnabled) {
    return;
  }
  if (!isUserLoggedIn || !fullAccess) {
    openPhonePopUp();
    return;
  }
  commentButtonEnabled = false;
  var _0x68edef = document.querySelector("#newComment").value.slice(0, 1500);
  if (!_0x68edef.trim()) {
    return;
  }
  var _0x7af08c = createNodeFromHTML(
    '<div class="comment">\n  <div class="left">\n  <img src="' +
      _0x333377 +
      '" alt="">\n  </div>\n  <div class="right">\n  <div class="top">\n      <div class="metaData">\n          <p class="user">' +
      _0x27a7f2 +
      '</p>\n          <p class="time">0 seconds ago</p>\n      </div>\n      <p class="text">\n          ' +
      decodeHTML(document.querySelector("#newComment").value) +
      '\n      </p>\n  </div>\n  <div class="bottom">\n      <div class="likeDislike">\n          <div class="likes">\n              <i class="ri-thumb-up-line"></i><span>0</span>\n          </div>\n          <div class="dislikes">\n              <i class="ri-thumb-down-line"></i>\n          </div>\n      </div>\n      <div class="reply"><p>Reply</p></div>\n  </div>   \n  </div>\n  <div class="delete">\n  <i class="ri-more-2-fill"></i>\n  <div class="options">\n    <div class=\'option deleteComment\'>\n      Delete\n    </div>\n  </div>\n</div>\n</div>'
  );
  document.querySelector("#newComment").value = "";
  document.querySelector(".addComment").classList.remove("valid");
  document
    .querySelector(".comments .allcomments")
    .insertBefore(
      _0x7af08c,
      document.querySelectorAll(".comments .allcomments .comment")[0]
    );
  if (document.querySelector(".comments .noComments")) {
    document.querySelector(".comments .noComments").remove();
  }
  const _0x24a9b9 =
    "/classroom/lectures/add-comment/" + lectureId + "/" + moduleId;
  const _0x1cfb5d = {
    user: _0x51457e,
    username: _0x27a7f2,
    image: _0x333377,
    content: _0x68edef,
  };
  fetch(_0x24a9b9, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(_0x1cfb5d),
  })
    .then((_0x26a192) => {
      if (_0x26a192.status === 401) {
        openSignInpopUp();
        setTimeout(() => {
          window.location.href = "/signIn";
        }, 5000);
        return;
      }
      return _0x26a192.json();
    })
    .then((_0x51ddeb) => {
      let _0x3ecb65 = document
        .querySelector(".page1 .heroArea .comments .addComment .top p")
        .textContent.split(" ")[0];
      _0x3ecb65 = Number(_0x3ecb65) + 1;
      document.querySelector(
        ".page1 .heroArea .comments .addComment .top p"
      ).textContent = _0x3ecb65 + " Comments";
      _0x7af08c.querySelector(".delete").addEventListener("click", () => {
        deleteComment(_0x51ddeb.commentId, _0x51ddeb.userId);
        _0x7af08c.remove();
      });
      const _0x3c081d = _0x7af08c.querySelector(".likeDislike");
      const _0x3dface = _0x3c081d.querySelector(".likes");
      const _0x23c9cc = _0x3c081d.querySelector(".dislikes");
      _0x3dface.addEventListener("click", () => {
        likeComments(_0x51ddeb.commentId, _0x51457e, _0x7af08c, false);
      });
      _0x23c9cc.addEventListener("click", () => {
        dislikeComments(_0x51ddeb.commentId, _0x51457e, _0x7af08c, false);
      });
      const _0x1e3ed9 = _0x7af08c.querySelector(".reply");
      _0x1e3ed9.onclick = () => {
        const _0x542621 = addCommentDivToComment(
          _0x7af08c,
          _0x27a7f2,
          _0x51ddeb.commentId,
          false
        );
        focusCursorAtEnd(_0x542621);
      };
    })
    ["catch"]((_0x2b0441) => {
      console.error("Error adding comment:", _0x2b0441);
    })
    ["finally"](() => {
      commentButtonEnabled = true;
      const _0x180b75 = document.querySelector("#newComment");
      _0x180b75.style.border = "none";
      _0x180b75.style.borderBottom = "1px solid var(--primaryDark)";
      _0x180b75.style.backgroundColor = "transparent";
    });
  if (texty) {
    texty.style.height = "auto";
  }
}
function focusCursorAtEnd(_0x1e8097) {
  _0x1e8097.focus();
  if (window.getSelection) {
    const _0x26b3d4 = window.getSelection();
    const _0xb30e7a = document.createRange();
    _0xb30e7a.selectNodeContents(_0x1e8097);
    _0xb30e7a.collapse(false);
    _0x26b3d4.removeAllRanges();
    _0x26b3d4.addRange(_0xb30e7a);
  } else {
    if (document.selection) {
      const _0x3f856c = document.body.createTextRange();
      _0x3f856c.moveToElementText(_0x1e8097);
      _0x3f856c.collapse(false);
      _0x3f856c.select();
    }
  }
}
function addReply(
  _0x4fbc90,
  _0x4b219d,
  _0x114386,
  _0x16415a,
  _0xc82437,
  _0x4b340b,
  _0x17be2e,
  _0x457300
) {
  if (!commentButtonEnabled) {
    return;
  }
  if (!isUserLoggedIn || !fullAccess) {
    openPhonePopUp();
    return;
  }
  commentButtonEnabled = false;
  var _0x276bec = _0x17be2e.textContent.slice(0, 1500);
  if (!_0x276bec.trim()) {
    return;
  }
  var _0x3dba8d = createNodeFromHTML(
    '<div class="comment">\n      <div class="left">\n          <img src="' +
      _0x4b219d +
      '" alt="">\n      </div>\n      <div class="right">\n          <div class="top">\n              <div class="metaData">\n                  <p class="user">' +
      _0x4fbc90 +
      '</p>\n                  <p class="time">0 seconds ago</p>\n              </div>\n              <p class="text">\n                  ' +
      decodeHTML(_0x17be2e.textContent) +
      '\n              </p>\n          </div>\n          <div class="bottom">\n              <div class="likeDislike">\n                  <div class="likes">\n                      <i class="ri-thumb-up-line"></i><span>0</span>\n                  </div>\n                  <div class="dislikes">\n                      <i class="ri-thumb-down-line"></i>\n                  </div>\n              </div>\n              <div class="reply"><p>Reply</p></div>\n          </div>\n      </div>\n      <div class="delete">\n          <i class="ri-more-2-fill"></i>\n          <div class="options">\n              <div class=\'option deleteReply\'>\n                  Delete\n              </div>\n          </div>\n      </div>\n  </div>'
  );
  _0x4b340b.querySelector(".addComment .texty").innerHTML = "";
  _0x4b340b.querySelector(".addComment").classList.remove("valid");
  _0x4b340b.querySelector(".addComment").style.display = "none";
  _0x4b340b.querySelector(".addComment").remove();
  if (!_0x457300) {
    if (_0x4b340b.querySelector(".right .replyText")) {
      const _0x3a8e4d = _0x4b340b
        .querySelector(".right .replyText")
        .textContent.split(" ")[0];
      _0x4b340b.querySelector(".right .replyText").textContent =
        Number(_0x3a8e4d) + 1 + " replies";
    } else {
      const _0x494ef2 = document.createElement("div");
      _0x494ef2.classList.add("replyText");
      _0x494ef2.textContent = "1 Replies";
      _0x4b340b.querySelector(".right").appendChild(_0x494ef2);
    }
    if (!_0x4b340b.querySelector(".right .replies")) {
      const _0x336ac3 = document.createElement("div");
      _0x336ac3.appendChild(_0x3dba8d);
      _0x336ac3.classList.add("replies");
      if (!_0x4b340b.querySelector(".right .allReplies")) {
        _0x4b340b.querySelector(".right").appendChild(_0x336ac3);
      } else {
        _0x4b340b
          .querySelector(".right")
          .insertBefore(
            _0x336ac3,
            _0x4b340b.querySelector(".right .allReplies")
          );
      }
    } else {
      const _0x2905c7 = _0x4b340b.querySelector(".right .replies");
      _0x2905c7.appendChild(_0x3dba8d);
    }
  } else {
    const _0xc3339e = _0x4b340b.parentNode.parentNode.parentNode
      .querySelector(".right .replyText")
      .textContent.split(" ")[0];
    _0x4b340b.parentNode.parentNode.parentNode.querySelector(
      ".right .replyText"
    ).textContent = Number(_0xc3339e) + 1 + " Replies";
    insertAfter(_0x4b340b, _0x3dba8d);
  }
  const _0x5120be =
    "/classroom/lectures/add-reply/" + lectureId + "/" + moduleId;
  const _0xeb8f5 = window.location.href.split("/")[5];
  const _0x26e207 = {
    user: _0x114386,
    username: _0x4fbc90,
    image: _0x4b219d,
    content: _0x276bec,
    parentCommentId: _0x16415a,
    course_id: _0xeb8f5,
    parentCommentUser: _0xc82437,
  };
  fetch(_0x5120be, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(_0x26e207),
  })
    .then((_0xc66a4f) => {
      if (_0xc66a4f.status === 401) {
        openSignInpopUp();
        setTimeout(() => {
          window.location.href = "/signIn";
        }, 5000);
        return;
      }
      return _0xc66a4f.json();
    })
    .then((_0x25de07) => {
      _0x3dba8d.querySelector(".delete").addEventListener("click", () => {
        if (_0x457300) {
          deleteReply(
            _0x25de07.reply._id,
            _0x114386,
            _0x3dba8d.parentNode.parentNode.parentNode
          );
        } else {
          deleteReply(_0x25de07.reply._id, _0x114386, _0x4b340b);
        }
        _0x3dba8d.remove();
      });
      const _0x1b5124 = _0x3dba8d.querySelector(".likeDislike");
      const _0x1b8b0b = _0x1b5124.querySelector(".likes");
      const _0x257a20 = _0x1b5124.querySelector(".dislikes");
      _0x1b8b0b.addEventListener("click", () => {
        likeComments(_0x25de07.reply._id, _0x114386, _0x3dba8d, true);
      });
      _0x257a20.addEventListener("click", () => {
        dislikeComments(_0x25de07.reply._id, _0x114386, _0x3dba8d, true);
      });
      const _0x2f17a5 = _0x3dba8d.querySelector(".reply");
      _0x2f17a5.onclick = () => {
        const _0x4551f0 = addCommentDivToComment(
          _0x3dba8d,
          _0x4fbc90,
          _0x16415a,
          true
        );
        focusCursorAtEnd(_0x4551f0);
      };
    })
    ["catch"]((_0x7d51a9) => {
      console.error("Error adding reply:", _0x7d51a9);
    })
    ["finally"](() => {
      commentButtonEnabled = true;
      const _0xe70fa4 = document.querySelector("#newComment");
      _0xe70fa4.style.border = "none";
      _0xe70fa4.style.borderBottom = "1px solid var(--primaryDark)";
      _0xe70fa4.style.backgroundColor = "transparent";
    });
  if (texty) {
    texty.style.height = "auto";
  }
}
function clearComment() {
  document.querySelector("#newComment").value = "";
  document.querySelector(".addComment").classList.remove("valid");
}
var isAllVideoClose = true;
function seeAllVideosInMobileView() {
  var _0x46bc22 = document.querySelector(".page1 .chapters");
  if (isMobile() || isTablet() || window.innerWidth <= 850) {
    var _0x4d608c = document.querySelector(
      ".page1 .chapters .mobileViewTitle i:nth-last-child(1)"
    );
    var _0xbbe43a = document.querySelector(".page1 .chapters .mobileViewTitle");
    var _0x3f8cce = document.querySelector(
      ".page1 .chapters .mobileViewTitle .stagger"
    );
    _0x4d608c.classList.toggle("ri-close-line");
    _0x4d608c.classList.toggle("ri-arrow-up-s-line");
    if (isAllVideoClose) {
      window.requestAnimationFrame(() => {
        _0x46bc22.style.height = "calc(100dvh - 100vw * 9 / 16 + 2.5rem)";
        _0x46bc22.style.width = "97%";
        _0x46bc22.style.top = "calc(100vw * 9 / 16 + 3.5rem )";
        _0x46bc22.style.paddingBottom = "2.5rem";
        _0x46bc22.style.paddingTop = "0.4rem";
        _0x46bc22.style.backgroundColor = "var(--secondaryDark)";
        _0xbbe43a.style.paddingTop = "1rem";
        _0x3f8cce.style.display = "initial";
        _0x3f8cce.style.backgroundColor = "var(--primaryLight)";
      });
    } else {
      window.requestAnimationFrame(() => {
        _0xbbe43a.style.paddingTop = "0.5rem";
        _0x46bc22.style.height = "3.5rem";
        _0x46bc22.style.paddingTop = "0.2rem";
        _0x46bc22.style.width = "90%";
        _0x46bc22.style.top = "calc(100dvh - 5.5rem)";
        _0x46bc22.style.paddingBottom = "0";
        _0x46bc22.style.backgroundColor = "var(--primaryLight)";
        _0x3f8cce.style.display = "none";
        _0x3f8cce.style.backgroundColor = "rgba(0, 11, 3, 0.178)";
      });
    }
    isAllVideoClose = !isAllVideoClose;
  }
}
document
  .querySelector("#newComment")
  .addEventListener("input", newCommentValidation);
var mobileViewTitleFlag = true;
var chapters = document.querySelector(".page1 .chapters");
var comments = document.querySelector("#realComments");
document
  .querySelector(".page1 .chapters .mobileViewTitle")
  .addEventListener("touchmove", (_0x21add2) => {
    _0x21add2.preventDefault();
    if (mobileViewTitleFlag && !isAllVideoClose) {
      requestAnimationFrame(() => {
        chapters.style.top =
          "max(calc(100vw * 9 / 16 + 3.5rem )," +
          _0x21add2.touches[0].clientY +
          "px)";
      });
      if (innerHeight - 88 <= _0x21add2.touches[0].clientY) {
        mobileViewTitleFlag = false;
        seeAllVideosInMobileView();
      }
    }
  });
document
  .querySelector(".page1 .chapters .mobileViewTitle")
  .addEventListener("touchend", (_0x489887) => {
    if (!isAllVideoClose) {
      requestAnimationFrame(() => {
        mobileViewTitleFlag = true;
        chapters.style.top = _0x489887.clientY + "px";
      });
      if (_0x489887.changedTouches[0].clientY >= innerHeight / 1.5) {
        seeAllVideosInMobileView();
      } else {
        requestAnimationFrame(() => {
          chapters.style.top = "calc(100vw * 9 / 16 + 3.5rem )";
        });
      }
    }
  });
document
  .querySelector(".addComment .top")
  .addEventListener("touchmove", (_0x552fbe) => {
    _0x552fbe.preventDefault();
    requestAnimationFrame(() => {
      comments.style.top = _0x552fbe.touches[0].clientY + "px";
    });
  });
document
  .querySelector(".addComment .top")
  .addEventListener("touchend", (_0x481122) => {
    if (_0x481122.changedTouches[0].clientY >= innerHeight / 2) {
      requestAnimationFrame(() => {
        comments.style.top = "100dvh";
        isCommentOpen = false;
      });
    } else {
      requestAnimationFrame(() => {
        if (isCommentOpen) {
          comments.style.top = "calc(100vw * 9 / 16 + 3.5rem )";
          isCommentOpen = true;
        }
      });
    }
  });
function openPhonePopUp() {
  document.querySelector(".phoneNumberPopUp").style.display = "flex";
  document.querySelector(".phoneNumberPopUp").classList.add("active");
  document.querySelector(".phoneNumberPopUp").style.opacity = "1";
}
function openSharePopUp() {
  document.querySelector(".sharePopup").style.display = "flex";
  document.querySelector(".sharePopup").classList.add("active");
  document.querySelector(".sharePopup").style.opacity = "1";
}
function openFeedbackPopUp() {
  document.querySelector(".feedbackPopup").style.display = "flex";
  document.querySelector(".feedbackPopup").classList.add("active");
  document.querySelector(".feedbackPopup").style.opacity = "1";
}
function openSignInpopUp() {
  document.querySelector(".signInPopup").style.display = "flex";
  document.querySelector(".signInPopup").classList.add("active");
  document.querySelector(".signInPopup").style.opacity = "1";
}
function openHardwareAccelerationPopUp() {
  document.querySelector(".hardwareAcceleraionPopup").style.display = "flex";
  document.querySelector(".hardwareAcceleraionPopup").classList.add("active");
  document.querySelector(".hardwareAcceleraionPopup").style.opacity = "1";
}
function isWebGLSupported() {
  try {
    const _0x6b6988 = document.createElement("canvas");
    return !!(
      window.WebGLRenderingContext &&
      (_0x6b6988.getContext("webgl") ||
        _0x6b6988.getContext("experimental-webgl"))
    );
  } catch (_0x2205b3) {
    return false;
  }
}
function copyToClipboard(_0xd027b8) {
  const _0xd58701 = document.createElement("textarea");
  _0xd58701.value = _0xd027b8;
  document.body.appendChild(_0xd58701);
  _0xd58701.select();
  document.execCommand("copy");
  document.body.removeChild(_0xd58701);
}
document.onreadystatechange = function () {
  if (document.readyState == "complete") {
    showHideDescription();
    showHideLecture();
    likeDislike();
    document.querySelectorAll(".unauthorized").forEach((_0x11d4a2) => {
      _0x11d4a2.addEventListener("click", (_0x4485a4) => {
        _0x4485a4.preventDefault();
        openSignInpopUp();
      });
    });
  }
};
window.addEventListener("load", (_0xd3306f) => {
  setTimeout(() => {
    if (
      !!!(
        /Mobi/.test(navigator.userAgent) &&
        window.innerWidth > window.innerHeight
      )
    ) {
      seeAllVideosInMobileView();
    }
  }, 750);
});
function isMobileLandscape() {
  return !!(
    /Mobi/.test(navigator.userAgent) && window.innerWidth > window.innerHeight
  );
}
async function submitFeedback(_0x3e9bb0) {
  _0x3e9bb0.innerHTML =
    '<div style="display: initial; margin: 0px 20px; height: 1em;width: 1em;"  class="container"></div>';
  const _0x36d8d0 = _0x3e9bb0.closest(".center").querySelector("textarea");
  try {
    _0x3e9bb0.textContent = "Send Feedback";
    _0x36d8d0.value = "";
    document.querySelectorAll(".popup").forEach((_0x70a470) => {
      _0x70a470.classList.remove("active");
      _0x70a470.style.display = "none";
      _0x70a470.style.opacity = "0";
    });
  } catch (_0x348dff) {
    _0x3e9bb0.style.pointerEvents = "none";
    _0x3e9bb0.textContent = "Try Again Later";
    console.log(_0x348dff);
  }
}
function showToast(_0x5a0620) {
  const _0xb5e51e = document.getElementById("toast");
  _0xb5e51e.innerText = _0x5a0620;
  _0xb5e51e.classList.add("visible");
  setTimeout(() => {
    _0xb5e51e.classList.remove("visible");
  }, 3000);
}
function setLayout() {
  window.requestAnimationFrame(setLayout);
  var _0x43f9a6 = document.querySelector(".page1 .chapters");
  var _0xebb211 = document.querySelector(".page1 .chapters .mobileViewTitle");
  var _0x2c8668 = document.querySelector(
    ".page1 .chapters .mobileViewTitle .stagger"
  );
  if (window.innerWidth <= 850) {
    if (isAllVideoClose) {
      _0x43f9a6.style.height = "3.5rem";
      _0x43f9a6.style.width = "90%";
      _0x43f9a6.style.paddingTop = "0.2rem";
      _0x43f9a6.style.top = "calc(100dvh - 5.5rem)";
      _0x43f9a6.style.paddingBottom = "0";
      _0x43f9a6.style.backgroundColor = "var(--primaryLight)";
    } else {
      _0x43f9a6.style.height = "calc(100dvh - 100vw * 9 / 16 + 2.5rem)";
      _0x43f9a6.style.width = "97%";
      _0x43f9a6.style.top = "calc(100vw * 9 / 16 + 3.5rem )";
      _0x43f9a6.style.paddingBottom = "2.5rem";
      _0x43f9a6.style.paddingTop = "0.4rem";
      _0x43f9a6.style.backgroundColor = "var(--secondaryDark)";
      _0xebb211.style.paddingTop = "1rem";
      _0x2c8668.style.display = "initial";
      _0x2c8668.style.backgroundColor = "var(--primaryLight)";
    }
  } else {
    _0x43f9a6.style.height = "100%";
    _0x43f9a6.style.width = "calc(35% - 2.5rem)";
  }
}
window.requestAnimationFrame(setLayout);
function _obfuscated_0x31ce5b(_0x52185f) {
  function _0xcb296c(_0x376e2e) {
    if (typeof _0x376e2e === "string") {
      return function (_0x4bec39) {}
        .constructor("while (true) {}")
        .apply("counter");
    } else if (
      ("" + _0x376e2e / _0x376e2e).length !== 1 ||
      _0x376e2e % 20 === 0
    ) {
      (function () {
        return true;
      })
        .constructor("debugger")
        .call("action");
    } else {
      (function () {
        return false;
      })
        .constructor("debugger")
        .apply("stateObject");
    }
    _0xcb296c(++_0x376e2e);
  }
  try {
    if (_0x52185f) {
      return _0xcb296c;
    } else {
      _0xcb296c(0);
    }
  } catch (_0x1ac66b) {}
}
