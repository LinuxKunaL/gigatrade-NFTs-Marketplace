import React from "react";

function Section_5() {
  return (
    <div
      id="section-5"
      className="flex mt-5 gap-6 lg:gap-20 flex-col  lg:h-[20pc] w-full"
    >
      <h1 className="dark:text-white/90 text-2xl sm:text-4xl">
        Top Seller in{" "}
        <b className="border-2 sm:text-2xl text-lg lg:shadow-none lg:shadow-purple-800/80 sm:border-0 rounded-md shadow-lg shadow-purple-800/80 p-1 bg-gradient-to-r from-purple-600 via-pink-600 to-blue-500">
          All Time
        </b>
      </h1>
      <div className="flex flex-col gap-10 flex-wrap">
        <div className="flex w-full justify-between gap-4 flex-wrap">
          <div
            id="user-box"
            className="flex justify-between items-center w-full sm:w-[13pc]"
          >
            <img
              className="w-14 rounded-full outline-darkBlue-200 outline-double "
              src="https://rainbowit.net/html/nuron/assets/images/client/client-12.png"
              alt=""
            />
            <div>
              <h2 className=" cursor-pointer transition-all text-white/90 font-semibold text-lg hover:text-purple-600">
                Baby doge{" "}
              </h2>
              <span className="text-white/50 text-sm">$2500,000</span>
            </div>
            <h3 className="text-white/10 font-semibold text-5xl">1</h3>
          </div>
          <div
            id="user-box"
            className="flex justify-between items-center w-full sm:w-[13pc] "
          >
            <img
              className="w-14 rounded-full outline-darkBlue-200 outline-double "
              src="https://rainbowit.net/html/nuron/assets/images/client/client-2.png"
              alt=""
            />
            <div>
              <h2 className=" cursor-pointer transition-all text-white/90 font-semibold text-lg hover:text-purple-600">
                Ms. Parkline{" "}
              </h2>
              <span className="text-white/50 text-sm">$3500,000</span>
            </div>
            <h3 className="text-white/10 font-semibold text-5xl">2</h3>
          </div>{" "}
          <div
            id="user-box"
            className="flex justify-between items-center w-full sm:w-[13pc] "
          >
            <img
              className="w-14 rounded-full outline-darkBlue-200 outline-double "
              src="https://rainbowit.net/html/nuron/assets/images/client/client-3.png"
              alt=""
            />
            <div>
              <h2 className=" cursor-pointer transition-all text-white/90 font-semibold text-lg hover:text-purple-600">
                Methods{" "}
              </h2>
              <span className="text-white/50 text-sm">$1500,000</span>
            </div>
            <h3 className="text-white/10 font-semibold text-5xl">3</h3>
          </div>{" "}
          <div
            id="user-box"
            className="flex justify-between items-center w-full sm:w-[13pc] "
          >
            <img
              className="w-14 rounded-full outline-darkBlue-200 outline-double "
              src="https://rainbowit.net/html/nuron/assets/images/client/client-4.png"
              alt=""
            />
            <div>
              <h2 className=" cursor-pointer transition-all text-white/90 font-semibold text-lg hover:text-purple-600">
                Jone sone{" "}
              </h2>
              <span className="text-white/50 text-sm">$2500,000</span>
            </div>
            <h3 className="text-white/10 font-semibold text-5xl">4</h3>
          </div>{" "}
          <div
            id="user-box"
            className="flex justify-between items-center w-full sm:w-[13pc] "
          >
            <img
              className="w-14 rounded-full outline-darkBlue-200 outline-double "
              src="https://rainbowit.net/html/nuron/assets/images/client/client-5.png"
              alt=""
            />
            <div>
              <h2 className=" cursor-pointer transition-all text-white/90 font-semibold text-lg hover:text-purple-600">
                Siddhart{" "}
              </h2>
              <span className="text-white/50 text-sm">$2500,000</span>
            </div>
            <h3 className="text-white/10 font-semibold text-5xl">5</h3>
          </div>
        </div>
        <div className="flex w-full justify-between gap-4 flex-wrap">
          <div
            id="user-box"
            className="flex justify-between items-center w-full sm:w-[13pc] "
          >
            <img
              className="w-14 rounded-full outline-darkBlue-200 outline-double "
              src="https://rainbowit.net/html/nuron/assets/images/client/client-6.png"
              alt=""
            />
            <div>
              <h2 className=" cursor-pointer transition-all text-white/90 font-semibold text-lg hover:text-purple-600">
                Sobuj Mk{" "}
              </h2>
              <span className="text-white/50 text-sm">$2500,000</span>
            </div>
            <h3 className="text-white/10 font-semibold text-5xl">6</h3>
          </div>{" "}
          <div
            id="user-box"
            className="flex justify-between items-center w-full sm:w-[13pc] "
          >
            <img
              className="w-14 rounded-full outline-darkBlue-200 outline-double "
              src="https://rainbowit.net/html/nuron/assets/images/client/client-7.png"
              alt=""
            />
            <div>
              <h2 className=" cursor-pointer transition-all text-white/90 font-semibold text-lg hover:text-purple-600">
                Trodband{" "}
              </h2>
              <span className="text-white/50 text-sm">$2500,000</span>
            </div>
            <h3 className="text-white/10 font-semibold text-5xl">7</h3>
          </div>{" "}
          <div
            id="user-box"
            className="flex justify-between items-center w-full sm:w-[13pc] "
          >
            <img
              className="w-14 rounded-full outline-darkBlue-200 outline-double "
              src="https://rainbowit.net/html/nuron/assets/images/client/client-8.png"
              alt=""
            />
            <div>
              <h2 className=" cursor-pointer transition-all text-white/90 font-semibold text-lg hover:text-purple-600">
                Yash{" "}
              </h2>
              <span className="text-white/50 text-sm">$500,000</span>
            </div>
            <h3 className="text-white/10 font-semibold text-5xl">8</h3>
          </div>{" "}
          <div
            id="user-box"
            className="flex justify-between items-center w-full sm:w-[13pc] "
          >
            <img
              className="w-14 rounded-full outline-darkBlue-200 outline-double "
              src="https://rainbowit.net/html/nuron/assets/images/client/client-9.png"
              alt=""
            />
            <div>
              <h2 className=" cursor-pointer transition-all text-white/90 font-semibold text-lg hover:text-purple-600">
                YASHKIB{" "}
              </h2>
              <span className="text-white/50 text-sm">$20,000</span>
            </div>
            <h3 className="text-white/10 font-semibold text-5xl">9</h3>
          </div>{" "}
          <div
            id="user-box"
            className="flex justify-between items-center w-full sm:w-[13pc] "
          >
            <img
              className="w-14 rounded-full outline-darkBlue-200 outline-double "
              src="https://rainbowit.net/html/nuron/assets/images/client/client-10.png"
              alt=""
            />
            <div>
              <h2 className=" cursor-pointer transition-all text-white/90 font-semibold text-lg hover:text-purple-600">
                Brodband{" "}
              </h2>
              <span className="text-white/50 text-sm">$1,000</span>
            </div>
            <h3 className="text-white/10 font-semibold text-5xl">10</h3>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Section_5;
